===================================================
Localead Desktop App - Offline/Local Installation Instructions
===================================================

This ZIP file contains the full local source code for Localead.

System Requirements:
- Node.js (v18.0.0 or higher) installed on your system.
  Download link: https://nodejs.org/

How to Run:
1. Double-click the "start-local.bat" file. This will automatically:
   - Run "npm install" to install all necessary packages.
   - Open "http://localhost:3000" in your default web browser.
   - Run "npm run dev" to launch the local Node server.

2. (Optional) If you want to use MongoDB or live AI search:
   - Rename ".env.example" to ".env.local"
   - Input your MONGODB_URI and API keys in ".env.local".

3. Default Admin Credentials:
   - Email: admin@localead
   - Password: locallead14062026