@echo off
echo ===================================================
echo   Localead Desktop App - Offline/Local Launcher
echo ===================================================
echo.
echo Installing node dependencies (this may take a minute)...
call npm install
echo.
echo Launching the development server...
start http://localhost:3000
call npm run dev
pause